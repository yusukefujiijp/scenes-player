# assets/ — 規格メモ
- **og-image.png**: 1200×630（最小 800×418 でも可）/ ≤ 500 KB / JPG or PNG  
- **favicon.svg**: SVG推奨（.ico 併用可）  
- 命名は **kebab-case**（例: `og-image.png`, `favicon.svg`）  
- 置き換え後は **Facebook Sharing Debugger** と **X Card** で更新確認
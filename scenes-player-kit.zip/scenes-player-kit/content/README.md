# content/ — 台本アーカイブ方針
- 現行はルートの `scenes.json`。過去分は本フォルダに **DayX_YYYYMMDD.json** で保存  
- 例: `Day3_20250901.json`  
- 手順: 1) 既存を content/へ日付付きコピー → 2) ルート `scenes.json` を更新 → 3) 再生検証